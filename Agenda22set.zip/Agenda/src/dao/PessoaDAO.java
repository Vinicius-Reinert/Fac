package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaDAO {
	
private ConexaoPadrao con;
	
	public PessoaDAO(){
		this.con = new ConexaoPadrao();
	}
    
	public void listarPessoas()throws SQLException {
		ResultSet resultado  = 
				con.obterStatement().executeQuery("select * from pessoa");
		
		while (resultado.next()) {
			System.out.print(resultado.getString(1) + " - ");
			System.out.println(resultado.getString("nome"));
			
		}
		
		resultado.close(); //--fecha a conexão --
	}

}
