package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.modelo.TipoDeTelefone;

public class FoneDAO {
	private ConexaoPadrao con;
	
	public FoneDAO(){
		this.con = new ConexaoPadrao();
	}
    
	
	public List<TipoDeTelefone> listarTipoFone()throws SQLException {
		ResultSet resultado  = 
				con.obterStatement().
				executeQuery("select * from tipofone ORDER BY DESCRICAO");
		
			List<TipoDeTelefone> lista = new ArrayList<TipoDeTelefone>();
		
			while (resultado.next()) {
				TipoDeTelefone tipo = new TipoDeTelefone();
			
			int codigo = resultado.getInt("codigo");
			String descricao = resultado.getString("descricao");
		
			tipo.setCodigo(codigo);
			tipo.setDescricao(descricao);
			
			lista.add(tipo);
		}
			resultado.close(); //--fecha a conexão --
		
		return lista;
	}
	
	public void incluirTipoFone (TipoDeTelefone tipo)throws SQLException {
		StringBuilder sb = new StringBuilder();
		
		sb.append("insert into tipofone(descricao)");
		sb.append("values ('");
		sb.append(tipo.getDescricao());
		sb.append("') ");
		
		System.out.println(sb.toString());
		con.obterStatement().execute(sb.toString());
		
				con.close();
	}	
//		public void excluirTipoFone (int codigo)throws SQLException {
//					StringBuilder sb = new StringBuilder();
//					
//					sb.append("delete from tipofone where codigo = ");
//					sb.append(codigo);
//					
//					con.obterStatement().execute(sb.toString());
//					
//					con.close();
//	}
	public void atualizarTipoFone (TipoDeTelefone tipo)throws SQLException {
	StringBuilder sb = new StringBuilder();
	
	sb.append(" update tipofone set ");
	sb.append(" descricao ='");
	sb.append(tipo.getDescricao());
	sb.append("'");
	sb.append(" WHERE CODIGO = ");
	sb.append(tipo.getCodigo());
	
	con.obterStatement().execute(sb.toString());
	

			con.close();
}
	
	
}