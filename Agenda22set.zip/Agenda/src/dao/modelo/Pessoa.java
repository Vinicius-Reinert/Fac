package dao.modelo;

import java.util.Date;

public class Pessoa {
	
	private Integer codigo;
	private String nome;
	private Date dataDeAniversario;
	private Endereco endereco;
	
	
	// isso � um servi�o dentro de uma classe que manipula as a��es dentro da classe
		//public void setCodigo(Integer valor){
				//	if (valor > 10){
				//		valor = valor / 2;
			    //		}
				//	else{
				//	valor = valor * 2;
				//	}
		//	codigo = valor;
	//}
	// isso � um servi�o dentro de uma classe que manipula as a��es dentro da classe
	
	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public Date getDataDeAniversario() {
		return dataDeAniversario;
	}


	public void setDataDeAniversario(Date dataDeAniversario) {
		this.dataDeAniversario = dataDeAniversario;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}


	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}


	public Integer getCodigo(){
		return codigo;
		
	}
}
