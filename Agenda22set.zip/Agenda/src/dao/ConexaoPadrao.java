package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexaoPadrao {
    private  Connection conexao = null;
    
	public  Connection obterConexao() {
		String url = "jdbc:postgresql://localhost:5432/agendadb";
		String usuario = "postgres";
		String senha = "vsr1985";

		if (conexao == null){
            try {
                Class.forName("org.postgresql.Driver");
                conexao = DriverManager.getConnection(url, usuario, senha);
            } catch (ClassNotFoundException e1) {
                System.out.println("Classe não encontrada");
                System.exit(0);
            } catch (SQLException e) {
                
                e.printStackTrace();
            }
            
        }
    	return conexao;		
	}
	
	public void close(){
        try {
            conexao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        conexao = null;
    }
	
	public  Statement obterStatement() {
		try {
			return obterConexao().createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}}
	
