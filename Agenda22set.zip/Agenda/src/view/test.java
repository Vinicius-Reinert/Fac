package view;

import dao.modelo.Pessoa;

public class test {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
    // P � o tipo de variavel de pessoa e atraves do p eu 
	//posso acessar todos os abrituos e objetos da classe pessoa
		
		//p.setCodigo(50); //isso ir� chamar o objeto na classe pessoa
			
		System.out.println("codigo1:\n " + p.getCodigo());
		
		//p.setCodigo(8); //isso ir� chamar o objeto na classe pessoa
		
		System.out.println("codigo2:\n " + p.getCodigo());

	}
//   \n � quebra de linha
}
