package exemploAcessoBanco;

import java.sql.SQLException;
import java.util.List;
import dao.FoneDAO;
import dao.modelo.TipoDeTelefone;


public class Teste {

	public static void main(String[] args) {
		FoneDAO dao = new FoneDAO();
	
		TipoDeTelefone tipo = new TipoDeTelefone();
	tipo.setDescricao("deu certo");
	
		try {
			System.out.println("incluir tipo fone.");
			for (int i=1; i<10;i++){
				tipo.setDescricao(" teste " + i);
				dao.incluirTipoFone(tipo);
			}
		
//						dao.excluirTipoFone(8);
			
			
			
			
			tipo.setCodigo(1);
			tipo.setDescricao("telefone fixo");
			dao.atualizarTipoFone(tipo);
			
			System.out.println("verificar se incluiu");
			List<TipoDeTelefone> lista = dao.listarTipoFone();
		
			for(TipoDeTelefone obj: lista){			
			System.out.println(obj.getDescricao());
		}
	
					
	} catch (SQLException e) {
			e.printStackTrace();
	}

	}

}
